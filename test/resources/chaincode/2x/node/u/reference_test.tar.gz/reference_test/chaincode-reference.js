const StorageChaincode = require('./chaincode-storage');

module.exports = class ReferenceChaincode extends StorageChaincode {

};
